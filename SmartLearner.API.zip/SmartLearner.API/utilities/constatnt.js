const ROLES = {
  ADMIN: "admin",
  CUSTOMER: "customer",
  TRAINEEINSTRUCTOR: "traineeinstructor",
  THEORYLEARNER: "theorylearner",
};

module.exports = { ROLES };
